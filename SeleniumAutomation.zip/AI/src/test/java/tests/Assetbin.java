package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class Assetbin {
	public static void main(String[] args) throws InterruptedException {
	    
        System.setProperty("webdriver.chrome.driver", "/Applications/TurnoAI/chromedriver-mac-x64/chromedriver");
        
        ChromeDriver driver = new ChromeDriver();
        driver.get ("https://devapp.assetbin.com/login");
        
        driver.manage().window().maximize();
        

    
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
        emailField.sendKeys("mathivanan@nanonino.in");

        WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
        password.sendKeys("Test@1234");
        
        
        
        WebElement loginButton = driver.findElement(By.className("cus-darkbtn"));

        System.out.println("logged in successfully");
      
        
        driver.quit();
        
        
    }


}
