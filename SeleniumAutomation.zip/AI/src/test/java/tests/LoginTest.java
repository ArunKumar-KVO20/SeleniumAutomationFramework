package tests;

import org.testng.annotations.*;
import org.openqa.selenium.WebDriver;
import base.BaseTest;
import pages.LoginPage;
import utils.ExcelUtils;
import reports.ExtentReportManager;

import com.aventstack.extentreports.*;

public class LoginTest {
    WebDriver driver;
    ExtentReports extent;
    ExtentTest test;

    @BeforeSuite
    public void startReport() {
        extent = ExtentReportManager.createReport();
    }

    @Test
    public void testLogin() throws Exception {
        test = extent.createTest("Login Test");
        int rowCount = ExcelUtils.getRowCount("Sheet1");

        for (int i = 1; i <= rowCount; i++) {
            String username = ExcelUtils.getCellData("Sheet1", i, 0);
            String password = ExcelUtils.getCellData("Sheet1", i, 1);

            if (username == null || username.isBlank()) {
                test.info("Row " + i + " skipped due to empty username.");
                continue;
            }

            driver = new BaseTest().initializeDriver();
            driver.get("https://devdashboard.turno.ai/auth/login");

            LoginPage loginPage = new LoginPage(driver);
            loginPage.login(username, password);
            Thread.sleep(2000);

            String title = driver.getTitle();
            test.info("Page title after login: " + title);

            if (title.equals("Turno")) {
                test.pass("Login successful for: " + username);
            } else {
                test.fail("Login failed for: " + username);
            }

            driver.quit();
        }
    }

    @AfterSuite
    public void endReport() {
        extent.flush();
    }
}
