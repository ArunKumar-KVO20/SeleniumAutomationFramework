package utils;

import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.*;

public class ExcelUtils {

    public static String getCellData(String sheetName, int rowNum, int colNum) throws Exception {
        FileInputStream fis = new FileInputStream("TestData/LoginData.xlsx");
        Workbook workbook = WorkbookFactory.create(fis);
        Sheet sheet = workbook.getSheet(sheetName);
        Row row = sheet.getRow(rowNum);
        if (row == null) {
            fis.close();
            return "";
        }
        Cell cell = row.getCell(colNum);
        fis.close();
        if (cell == null) {
            return "";
        }
        return cell.toString();
    }

    public static int getRowCount(String sheetName) throws Exception {
        FileInputStream fis = new FileInputStream("TestData/LoginData.xlsx");
        Workbook workbook = WorkbookFactory.create(fis);
        Sheet sheet = workbook.getSheet(sheetName);
        int rowCount = sheet.getLastRowNum();
        fis.close();
        return rowCount;
    }
}