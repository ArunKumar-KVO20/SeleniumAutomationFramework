package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseTest {

	  public WebDriver initializeDriver() {
	        System.setProperty("webdriver.chrome.driver", "/Applications/TurnoAI/chromedriver-mac-x64/chromedriver");  // Replace with actual path
	        WebDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        return driver;
	}

}
